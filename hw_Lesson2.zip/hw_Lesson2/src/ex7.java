public class ex7 {
    public static void main(String[] arg) {
        char bukva = 'a';

        if ((bukva >= 'a' && bukva <= 'z') || (bukva <= 'a' && bukva >= 'z')) {
            System.out.println("bukva");
        } else {
            System.out.println("ne bukva");
        }

    }
}




