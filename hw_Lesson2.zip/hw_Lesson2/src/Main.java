public class Main {
    public static void main(String[] args){
        int a = 10;
        int b = 20;
        if(a <= b) {
            System.out.println("Максимальное число выявлено.");
        } else System.out.println("Максимальное число не выявлено.");

    }
}