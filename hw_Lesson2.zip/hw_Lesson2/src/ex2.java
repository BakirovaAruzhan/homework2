    public class ex2 {
        public static void main(String[] arg) {
            switch (30) {

                    case 10 -> System.out.println("макс число 10.");
                    case 20 -> System.out.println("макс число 20.");
                    case 30 -> System.out.println("макс число 30.");
                    default -> System.out.println("нет верного ответа.");

            }
        }
    }
