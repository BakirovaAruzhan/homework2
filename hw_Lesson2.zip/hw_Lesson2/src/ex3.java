public class ex3 {
    public static void main(String[] arg) {
        int number = 25;
        if (number<0){
            System.out.println("the number is negative");}
else if (number>0){
            System.out.println("the number is positive");}
else{
            System.out.println("the number is zero");}
        }
    }
